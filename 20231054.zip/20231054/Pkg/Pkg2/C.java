package Pkg.Pkg2

protected class C{
    int c;

    public void display(){
        System.out.println(c);
    }
}