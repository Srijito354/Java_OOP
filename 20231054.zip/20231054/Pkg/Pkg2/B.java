package Pkg.Pkg2;

private class B {
    int b;

    public void display() {
        System.out.println("Value of b = " + b);
    }
}