package Pkg.Pkg2;

public class A {
    int a;

    public void display() {
        System.out.println("Value of a = " + a);
    }
}