package Pkg.Pkg2;

class D{
    int d;

    public void display(){
        System.out.println(d);
    }
}