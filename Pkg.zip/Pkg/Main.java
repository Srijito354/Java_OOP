import Pkg.A;

class Main {
    public static void main(String[] args) {
        A A_obj = new A();
        A_obj.a = 10;
        A_obj.display();
    }
}
