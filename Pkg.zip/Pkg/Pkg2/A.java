package Pkg.Pkg2;

public class A {
    public int a;

    public void display() {
        System.out.println("Value of a = " + a);
    }
}