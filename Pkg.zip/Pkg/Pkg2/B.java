package Pkg.Pkg2;

private class A {
    public int a;

    public void display() {
        System.out.println("Value of a = " + a);
    }
}